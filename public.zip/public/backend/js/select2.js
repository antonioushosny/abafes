
// $(document).ready(function() {
// 	var select2 = $('.select2');
//     select2.select2({
//     	placeholder: select2.attr('placeholder'),
//     });
// });
